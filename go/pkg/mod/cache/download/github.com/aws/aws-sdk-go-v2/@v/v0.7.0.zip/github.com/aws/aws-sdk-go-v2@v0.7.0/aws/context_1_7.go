// +build go1.7

package aws

import "context"

var (
	backgroundCtx = context.Background()
)
