package main

//go:generate go run -tags codegen ./codegen/codegen.go ../../../../service
//go:generate gofmt -s -w .
