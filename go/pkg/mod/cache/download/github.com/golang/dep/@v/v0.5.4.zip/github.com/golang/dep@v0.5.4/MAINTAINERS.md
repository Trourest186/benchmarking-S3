
General maintainers:
    sam boyer (@sdboyer)

* dep
  * `init` command: Carolyn Van Slyck (@carolynvs)
  * `ensure` command: Ibrahim AshShohail (@ibrasho)
  * `status` command: Sunny (@darkowlzz)
  * testing harness: (vacant)
* gps
  * solver: (vacant)
  * source manager: (@jmank88)
  * root deduction: (vacant)
  * source/vcs interaction: (@jmank88)
  * caching: Jordan Krage (@jmank88)
  * pkgtree: (vacant)
  * versions and constraints: (@jmank88)
