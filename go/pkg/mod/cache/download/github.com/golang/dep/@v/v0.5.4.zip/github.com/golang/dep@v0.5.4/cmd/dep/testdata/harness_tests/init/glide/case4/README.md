Ignore glide config if glide.yaml is malformed and cannot be parsed correctly.
