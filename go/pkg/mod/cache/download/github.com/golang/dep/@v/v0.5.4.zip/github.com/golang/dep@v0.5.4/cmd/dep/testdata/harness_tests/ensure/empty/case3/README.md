Validate that packages imported in an ignored package are not
included in the manifest or lock.