Have two direct dependencies where one specifies a direct transient version,
and the other specified a greater than version. Both versions overlap so resolving should pass.